package main

import (
	"log"
	"net/http"

	"github.com/7dpk/keyvaluestore/datastore"
	"github.com/7dpk/keyvaluestore/handlers"
	"github.com/gorilla/mux"
)

func main() {
	datastore := datastore.NewDatastore()
	handler := &handlers.HTTPHandler{
		Datastore: datastore,
	}

	router := mux.NewRouter()
	router.HandleFunc("/", handler.HandleRequest).Methods("POST")

	log.Println("Server started")
	log.Fatal(http.ListenAndServe(":8080", router))
}
